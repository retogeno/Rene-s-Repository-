require "application_system_test_case"

class TrandetailsTest < ApplicationSystemTestCase
  setup do
    @trandetail = trandetails(:one)
  end

  test "visiting the index" do
    visit trandetails_url
    assert_selector "h1", text: "Trandetails"
  end

  test "creating a Trandetail" do
    visit trandetails_url
    click_on "New Trandetail"

    fill_in "Btcamount", with: @trandetail.BTCamount
    fill_in "Bank", with: @trandetail.bank
    fill_in "Product", with: @trandetail.product_id
    fill_in "Saleprice", with: @trandetail.saleprice
    fill_in "Transaction", with: @trandetail.transaction_id
    click_on "Create Trandetail"

    assert_text "Trandetail was successfully created"
    click_on "Back"
  end

  test "updating a Trandetail" do
    visit trandetails_url
    click_on "Edit", match: :first

    fill_in "Btcamount", with: @trandetail.BTCamount
    fill_in "Bank", with: @trandetail.bank
    fill_in "Product", with: @trandetail.product_id
    fill_in "Saleprice", with: @trandetail.saleprice
    fill_in "Transaction", with: @trandetail.transaction_id
    click_on "Update Trandetail"

    assert_text "Trandetail was successfully updated"
    click_on "Back"
  end

  test "destroying a Trandetail" do
    visit trandetails_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Trandetail was successfully destroyed"
  end
end

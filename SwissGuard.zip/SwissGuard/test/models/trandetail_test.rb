require 'test_helper'

class TrandetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

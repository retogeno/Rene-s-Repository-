class CreateProducts < ActiveRecord::Migration[5.2]
  def change
    create_table :products do |t|
      t.string :productname
      t.string :productimage
      t.text :description
      t.integer :category_id
      t.integer :supplier_id
      t.string :subcategory_1
      t.string :subcategory_2
      t.string :subcategory_3
      t.float :saleprice
      t.string :status
      t.float :purchaseprice
      t.integer :qtyonhand
      t.integer :reorderpoint
      t.integer :reorderqty

      t.timestamps
    end
  end
end

class CreateTrandetails < ActiveRecord::Migration[5.2]
  def change
    create_table :trandetails do |t|
      t.integer :transaction_id
      t.string :product_id
      t.float :saleprice
      t.string :bank
      t.integer :BTCamount

      t.timestamps
    end
  end
end

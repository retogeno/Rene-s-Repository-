Rails.application.routes.draw do
  get 'sessions/new'
  get 'sessions/create'
  get 'sessions/destroy'
  resources :saledetails
  resources :sales
  get 'secret/private'
  get 'secret/public'
  resources :advertisements
  get 'report/custlist'
  get 'report/prodlist'
  get 'report/salelist'
  get 'report/reportmenu'
  resources :trandetails
  resources :products
  resources :transactions
  resources :subscriptions
  resources :customers
  get 'home/index'
  get 'home/about'
  get 'home/catalog'
  get 'home/contact'
  get 'home/help'
  get 'home/privacy'
  get 'home/askname'
  post 'home/askname'
  post 'home/buy'
  post 'home/updatecart'
  post 'home/checkout'
  get 'cart', to: 'home#cart', as: 'cart'
  get 'home/search'
  post 'home/search'
    get 'login', to: 'sessions#new', as: 'login'
    delete 'logout', to: 'sessions#destroy', as: 'logout'  
    resources :sessions
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html


root 'home#index'







end

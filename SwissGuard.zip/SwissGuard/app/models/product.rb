class Product < ApplicationRecord

 validates :saleprice, numericality:true
 validates :purchaseprice, numericality:true
 validates :productname, presence:true
 validates :category_id, inclusion: { in: 0..10 }
    
    
    
    
end

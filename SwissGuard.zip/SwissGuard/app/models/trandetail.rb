class Trandetail < ApplicationRecord
    
validates :transaction_id, numericality: true



end

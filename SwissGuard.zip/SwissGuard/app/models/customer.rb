class Customer < ApplicationRecord
    validates :firstname, presence:true
    validates :lastname, presence:true
    validates :phone, presence:true 
    validates :email, format: { with: /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i, on: :create }
    validates :username, presence:true, uniqueness:true
    has_secure_password
    
  def person 
      firstname + " " + lastname
  end
    
    has_many :sale, dependent: :destroy
    has_one :subscription, dependent: :destroy
end

class Subscription < ApplicationRecord
    

validates :category_id, inclusion: { in: 0..10 }
    
   # class Subscription < ActiveRecord::Base
        # Each sale belongs to only 1 customer
        belongs_to :customer
    
   has_many :sale, dependent: :destroy
 
end

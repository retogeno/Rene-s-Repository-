class Transaction < ApplicationRecord
    
    
        # Each transaction belongs to only 1 customer
     #   belongs_to :customer
    
    
   # def custname
     #   firstname + " " + lastname
   # end
    
    #has_many :trandetail, dependent:  :destroy
    
end

class UsState < ApplicationRecord
end

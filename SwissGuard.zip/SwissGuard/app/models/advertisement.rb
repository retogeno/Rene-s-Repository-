class Advertisement < ApplicationRecord
end

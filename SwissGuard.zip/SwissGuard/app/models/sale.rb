class Sale < ApplicationRecord
    
    belongs_to :customer
    belongs_to :subscription
    
    has_many :saledetail, dependent: :destroy
    
end

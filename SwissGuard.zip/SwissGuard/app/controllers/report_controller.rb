class ReportController < ApplicationController
  def custlist
    @custdata = Customer.all
  end

  def prodlist
    @proddata = Product.all
  end

  def salelist
    @saledata = Transaction.all
  end

end
